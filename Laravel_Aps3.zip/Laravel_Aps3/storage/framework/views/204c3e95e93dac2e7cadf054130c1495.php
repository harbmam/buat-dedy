
<?php $__env->startSection('title', 'Form Buku'); ?>
<?php $__env->startSection('content_header'); ?>
<h1>Data Buku</h1>
<br/>
<a href="<?php echo e(route('buku.index')); ?>" class="btn btn-primary btn-md" role="button"><i class="fa fa-arrow-left"> Back</i></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>

<?php
$rs1 = App\Models\Pengarang::all();
$rs2 = App\Models\Penerbit::all();
$rs3 = App\Models\Kategori::all();
?>
<form method="POST" action="<?php echo e(route('buku.store')); ?>">
<?php echo csrf_field(); ?> 

<div class="form-group">
<label>ISBN</label>
<input type="text" name="isbn" class="form-control"/>
</div>

<div class="form-group">
<label>Judul</label>
<input type="text" name="judul" class="form-control"/>
</div>

<div class="form-group">
<label>Tahun Cetak</label>
<input type="text" name="thn_cetak" class="form-control"/>
</div>

<div class="form-group">
<label>Stok</label>
<input type="text" name="stok" class="form-control"/>
</div>

<div class="form-group">
<label>Pengarang</label>
<select class="form-control" name="idpengarang">
<option value="">-- Pilih Pengarang --</option>
<?php $__currentLoopData = $rs1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

<div class="form-group">
<label>Penerbit</label>
<select class="form-control" name="idpenerbit">
<option value="">-- Pilih Penerbit --</option>
<?php $__currentLoopData = $rs2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($pen->id); ?>"><?php echo e($pen->nama); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

<div class="form-group">
<label>Kategori</label>
<select class="form-control" name="idkategori">
<option value="">-- Pilih Kategori --</option>
<?php $__currentLoopData = $rs3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<button type="submit" class="btn btn-primary"
name="proses">Simpan</button>
<button type="reset" class="btn btn-warning"
name="unproses">Batal</button>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script> console.log('Hi'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/buku/c.blade.php ENDPATH**/ ?>