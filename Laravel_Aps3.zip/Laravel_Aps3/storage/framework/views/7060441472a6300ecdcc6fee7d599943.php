
<?php $__env->startSection('title', 'Data Pegawai'); ?>
<?php $__env->startSection('content_header'); ?>
<h1 class="fa fa-users"> Data Pegawai</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-info">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php
$ar_judul = ['No','NIP','Nama','Alamat','Email'];
$no = 1;
?>
<a class="btn btn-primary btn-md"
href="<?php echo e(route('pegawai.create')); ?>" role="button"><i class="fa fa-plus"> Tambah Pegawai</i></a><br/><br/>
<table class="table table-striped">
<thead>
<tr>
<?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<th><?php echo e($jdl); ?></th>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $ar_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($no++); ?></td>
<td><?php echo e($peg->nip); ?></td>
<td><?php echo e($peg->nama); ?></td>
<td><?php echo e($peg->alamat); ?></td>
<td><?php echo e($peg->email); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/pegawai/index.blade.php ENDPATH**/ ?>