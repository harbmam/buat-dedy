
Hello, <?php echo e($name); ?>.
<?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/hello.blade.php ENDPATH**/ ?>