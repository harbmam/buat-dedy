<?php 
$nama= "Bedu";
echo 'Hai Apa Kabar '.$nama.' ?';
?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/kondisi.blade.php ENDPATH**/ ?>