<?php
$nama = "Fawwaz";
$nilai = 90;
?>

<?php if($nilai >= 60): ?> <?php $ket = "Lulus"; ?>
<?php else: ?> <?php $ket = "Gagal"; ?>
<?php endif; ?>

Nama Siswa : <?php echo e($nama); ?>

<br/>Nilai : <?php echo e($nilai); ?>

<br/>Keterangan : <?php echo e($ket); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/nilai.blade.php ENDPATH**/ ?>