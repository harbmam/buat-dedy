
<?php $__env->startSection('title', 'Data Anggota'); ?>
<?php $__env->startSection('content_header'); ?>
<h1 class="fa fa-user-secret"> Form Anggota</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<!-- validasi form -->
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<form action="<?php echo e(route('anggota.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    
    <div class="form-group">
    <label for="">NIP</label>
    <input type="text" name="nip" class="form-control"/>
    </div>

    <div class="form-group">
    <label for="">Nama</label>
    <input type="text" name="nama" class="form-control"/>
    </div>

    <div class="form-group">
    <label for="">Alamat</label>
    <textarea name="alamat" class="form-control"></textarea>
    </div>

    <div class="form-group">
    <label for="">E-mail</label>
    <input type="email" name="email" class="form-control"/>
    </div>

    <a class="btn btn-primary btn-md"
    href="<?php echo e(route('anggota.index')); ?>" role="button"><i class="fa fa-arrow-left"> Back</i></a>
    <button type="submit" class="btn btn-primary"><i class="fa fa-check"> Simpan</i></button>
    
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script> console.log('Hi'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/anggota/form.blade.php ENDPATH**/ ?>