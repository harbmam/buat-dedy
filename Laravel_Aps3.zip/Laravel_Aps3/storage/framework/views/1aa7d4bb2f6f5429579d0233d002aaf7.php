<div style=
"background: #2596be; font-size: 20px; color: white; text-align:center ">
Created by: Harb Software Development @ 2024
</div><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/layouts/footer.blade.php ENDPATH**/ ?>