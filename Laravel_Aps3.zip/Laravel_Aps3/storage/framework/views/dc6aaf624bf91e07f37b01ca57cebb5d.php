
<?php $__env->startSection('title', 'Data Mahasantri'); ?>
<?php $__env->startSection('content_header'); ?>
<h3 class="fa fa-graduation-cap" > Data Mahasantri</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$ar_tabel = ['No','Nama','NIM','Jurusan','Mata Kuliah','Dosen Pengajar'];
$no = 1;
?>
<a class="btn btn-primary" href="<?php echo e(route('mahasantri.create')); ?>"
role="button">Tambah</a><br/><br/>
<table class="table table-striped">
<thead>
<tr>
<?php $__currentLoopData = $ar_tabel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<th><?php echo e($jdl); ?></th>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>   
</thead> 
<tbody>
<?php $__currentLoopData = $ar_mahasantri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($no++); ?></td>
<td><?php echo e($b->nama); ?></td>
<td><?php echo e($b->nim); ?></td>
<td><?php echo e($b->pen); ?></td>
<td><?php echo e($b->mt); ?></td>
<td><?php echo e($b->dos); ?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script> console.log('Hi'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/mahasantri/index.blade.php ENDPATH**/ ?>