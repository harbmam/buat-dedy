
<?php $__env->startSection('title', 'Form Buku'); ?>
<?php $__env->startSection('content_header'); ?>
<h1>Data Buku</h1>
<br>
<a href="<?php echo e(route('buku.index')); ?>" class="btn btn-primary btn-md" role="button"><i class="fa fa-arrow-left"> Back</i></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php
$rs1 = App\Models\Pengarang::all();
$rs2 = App\Models\Penerbit::all();
$rs3 = App\Models\Kategori::all();
?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('buku.update',$b->id)); ?>">

<?php echo csrf_field(); ?> 
<?php echo method_field('put'); ?> 

<div class="form-group">
<label>ISBN</label>
<input type="text" name="isbn" value="<?php echo e($b->isbn); ?>" class="form-control"/>
</div>

<div class="form-group">
<label>Judul</label>
<input type="text" name="judul" class="form-control" value="<?php echo e($b->judul); ?>" />
</div>

<div class="form-group">
<label>Tahun Cetak</label>
<input type="text" name="thn_cetak" class="form-control" value="<?php echo e($b->thn_cetak); ?>" />
</div>

<div class="form-group">
<label>Stok</label>
<input type="text" name="stok" class="form-control" value="<?php echo e($b->stok); ?>" />
</div>

<div class="form-group">
<label>Pengarang</label>
<select class="form-control" name="idpengarang">
<option value="">-- Pilih Pengarang --</option>
<?php $__currentLoopData = $rs1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$sel1 = ($p->id == $b->idpengarang) ? 'selected' : '';
?>
<option value="<?php echo e($p->id); ?>" <?php echo e($sel1); ?>><?php echo e($p->nama); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

<div class="form-group">
<label>Penerbit</label>
<select type="text" name="idpenerbit" class="form-control">
<option value="">-- Pilih Penerbit --</option>
<?php $__currentLoopData = $rs2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$sel2 = ($pen->id == $b->idpenerbit) ? 'selected' : '';
?>
<option value="<?php echo e($pen->id); ?>" <?php echo e($sel2); ?>><?php echo e($pen->nama); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

<div class="form-group">
<label>Kategori</label>
<select type="text" name="idkategori" class="form-control">
<option value="">-- Pilih Kategori --</option>
<?php $__currentLoopData = $rs3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$sel3 = ($pen->id == $b->idkategori) ? 'selected' : '';
?>
<option value="<?php echo e($pen->id); ?>" <?php echo e($sel3); ?>><?php echo e($pen->nama); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

<button type="submit" class="btn btn-primary"
name="proses">Ubah</button>
<button type="reset" class="btn btn-warning"
name="unproses">Batal</button>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/buku/e.blade.php ENDPATH**/ ?>