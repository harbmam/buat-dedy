
<?php $__env->startSection('title', 'Data Pengarang'); ?>
<?php $__env->startSection('content_header'); ?>
<h3 class="fa fa-address-book"> Data Pengarang</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-info">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php
$ar_judul = ['No','Nama','E-mail','HP','Foto'];
$no = 1;
?>
<a class="btn btn-primary" href="<?php echo e(route('pengarang.create')); ?>"
role="button">Tambah pengarang</a><br/><br/>
<table class="table table-striped">
<thead>
<tr>
<?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<th><?php echo e($jdl); ?></th>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead> 
<tbody>
<?php $__currentLoopData = $ar_pen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($no++); ?></td>
<td><?php echo e($p->nama); ?></td>
<td><?php echo e($p->email); ?></td>
<td><?php echo e($p->hp); ?></td>
<td><?php echo e($p->foto); ?></td>
<td>
    <form method="POST" action="<?php echo e(route('pengarang.destroy',$p->id)); ?>">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('delete'); ?> 
        <a class="btn btn-info" href="<?php echo e(route('pengarang.show',$p->id )); ?>">Detail</a>
        <a class="btn btn-success"href="<?php echo e(route('pengarang.edit',$p->id )); ?>">Edit</a>
        <button class="btn btn-danger" onclick="return confirm('Anda Yakin Data Dihapus?')">Hapus</button>
    </form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script> console.log('Hi'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/pengarang/index.blade.php ENDPATH**/ ?>