<?php
$no = 1;
//array scalar
$s1 = ['nama'=>'Fawwaz', 'nilai'=>90];
$s2 = ['nama'=>'Inaya', 'nilai'=>89];
$s3 = ['nama'=>'Bedu', 'nilai'=>59];
$s4 = ['nama'=>'Mimin', 'nilai'=>80];
$judul = ['No','Nama','Nilai','Keterangan'];
//array associative
$siswa = [$s1,$s2,$s3,$s4];
?>

<h3 align="center">Daftar Nilai Siswa</h3>
<table border="1" align="center" cellpadding="10">
<thead>
<tr bgcolor="pink">
<?php $__currentLoopData = $judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<th><?php echo e($jdl); ?></th>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$ket = ($sis['nilai'] >= 60) ? 'Lulus' : 'Gagal';
$warna = ($no % 2 == 0) ? 'greenyellow' : 'yellow';
?>
<tr bgcolor="<?php echo e($warna); ?>">
<td><?php echo e($no++); ?></td>
<td><?php echo e($sis['nama']); ?></td>
<td><?php echo e($sis['nilai']); ?></td>
<td><?php echo e($ket); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/daftar_nilai.blade.php ENDPATH**/ ?>