<h3>Data Santri</h3>
<table border="1">
    <!-- <tr>
    <th>Maha Santri 1: <?php echo e($mhs1); ?>, Asal: <?php echo e($asal1); ?></th>
    <th>Maha Santri 2: <?php echo e($mhs2); ?>, Asal: <?php echo e($asal2); ?></th>
    <th>Alamat</th>
    </tr> -->
    <tr>
        <th>Nomor</th>
        <th>Nama</th>
        <th>Alamat</th>
    </tr>
    <tr>
        <th>1</th>
        <td><?php echo e($mhs1); ?></td>
        <td><?php echo e($asal1); ?></td>
    </tr>
    <tr>
        <th>2</th>
        <td><?php echo e($mhs2); ?></td>
        <td><?php echo e($asal2); ?></td>
    </tr>
    <tr>
        <th>3</th>
        <td><?php echo e($mhs3); ?></td>
        <td><?php echo e($asal3); ?></td>
    </tr>
    <tr>
        <th>4</th>
        <td><?php echo e($mhs4); ?></td>
        <td><?php echo e($asal4); ?></td>
    </tr>
    <tr>
        <th>5</th>
        <td><?php echo e($mhs5); ?></td>
        <td><?php echo e($asal5); ?></td>
    </tr>
</table><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/data_santri.blade.php ENDPATH**/ ?>