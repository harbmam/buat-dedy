
<?php $__env->startSection('title', 'Data Anggota'); ?>
<?php $__env->startSection('content_header'); ?>
<h1 class="fa fa-user-secret"> Data Anggota</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<?php
$ar_judul = ['No','NIP','Nama','Alamat','Email'];
$no = 1;
?>
<a class="btn btn-primary btn-md"
href="<?php echo e(route('anggota.create')); ?>" role="button"><i class="fa fa-plus"> Tambah Anggota</i></a><br/><br/>
<table class="table table-striped">
<thead>
<tr>
<?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<th><?php echo e($jdl); ?></th>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $ar_anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($no++); ?></td>
<td><?php echo e($ang->nip); ?></td>
<td><?php echo e($ang->nama); ?></td>
<td><?php echo e($ang->alamat); ?></td>
<td><?php echo e($ang->email); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>       
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_Aps3\resources\views/anggota/index.blade.php ENDPATH**/ ?>