<?php 
$nama= "Bedu";
echo 'Hai Apa Kabar '.$nama.' ?';
?>