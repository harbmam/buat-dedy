<h3>Data Santri</h3>
<table border="1">
    <!-- <tr>
    <th>Maha Santri 1: {{ $mhs1 }}, Asal: {{$asal1}}</th>
    <th>Maha Santri 2: {{ $mhs2 }}, Asal: {{$asal2}}</th>
    <th>Alamat</th>
    </tr> -->
    <tr>
        <th>Nomor</th>
        <th>Nama</th>
        <th>Alamat</th>
    </tr>
    <tr>
        <th>1</th>
        <td>{{ $mhs1 }}</td>
        <td>{{$asal1}}</td>
    </tr>
    <tr>
        <th>2</th>
        <td>{{ $mhs2 }}</td>
        <td>{{$asal2}}</td>
    </tr>
    <tr>
        <th>3</th>
        <td>{{ $mhs3 }}</td>
        <td>{{$asal3}}</td>
    </tr>
    <tr>
        <th>4</th>
        <td>{{ $mhs4 }}</td>
        <td>{{$asal4}}</td>
    </tr>
    <tr>
        <th>5</th>
        <td>{{ $mhs5 }}</td>
        <td>{{$asal5}}</td>
    </tr>
</table>